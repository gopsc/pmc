#!/usr/bin/env python3
from _to_pmc import PmcComm
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
def main():
    comm = PmcComm()
    print(comm.cj_pmc('localhost', 8002, {"call": "shell", "path": "dir", "pwdd": script_dir, "args": '-a'}))
if __name__ == "__main__":
    main()