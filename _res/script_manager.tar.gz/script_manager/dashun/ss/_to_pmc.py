#!/usr/bin/env python3
import requests
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
def post_pmc(type, name, payload):
    response = requests.post(
            f'http://localhost:8012/api?call={type}&path={script_dir}/{name}',
            json=payload
    )
    return response.text

class PmcComm:
    '''并发机器通信'''
    def __init__(self):
        self.basedir = script_dir

    def post_pmc(self, type: str, name: str, payload) -> str:
        return post_pmc(type, name, payload)
    
    def post_to_pmc(self, port: int, type: str, name: str, payload: object) -> str:
        response = requests.post(f'http://localhost:{port}/api?call={type}&path={self.basedir}/{name}', json=payload)
        if response.status_code == 200:
            return response.text
        else:
            ...
            #raise
    def cj_pmc(self, addr:str, port:str, payload: object):
        response = requests.post(f'http://{addr}:{port}/api', json=payload)
        return response.text