#!/usr/bin/env lua
for i = 1, 10, 1 do
    print("Welcome to Lua! " .. i)
    os.execute("sleep 1")
end