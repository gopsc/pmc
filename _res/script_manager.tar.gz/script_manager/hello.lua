#!/usr/bin/env lua
for i = 1, 10, 1 do
    print("Hello, World! " .. i)
    os.execute("sleep 1")
end