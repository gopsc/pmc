package main

import (
	"net/http"
)

const (
	url = "http://localhost:8001/api/?call=&wait="
)

func get_script_arguments() []string {
	http.Get(url)
	return nil
}
