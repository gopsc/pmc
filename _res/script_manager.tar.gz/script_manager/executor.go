package main

import (
	"fmt"
	"os/exec"
	"sync"
)

type Executor struct {
	cmd *exec.Cmd
	wg  *sync.WaitGroup
}

func NewExecutor(script string, wg *sync.WaitGroup) *Executor {
	cmd := exec.Command(script)
	return &Executor{cmd: cmd, wg: wg}
}

func (e *Executor) Run() {
	defer e.wg.Done()
	output, err := e.cmd.CombinedOutput()
	if err != nil {
		println("脚本执行出错:", err.Error())
	}
	println("脚本输出:", string(output))
}

func (e *Executor) Stop() {
	if e.cmd.Process != nil {
		_ = e.cmd.Process.Kill()
	}
}

func (e *Executor) Kill() {
	if e.cmd.Process != nil {
		_ = e.cmd.Process.Kill()
		fmt.Println("已强制终止脚本:", e.cmd.Path)
	}
}
